# Introduction

This repository permet to an small industry without any ERP to reduce their Scrap cutting without too much calculation.
The interraction is easy because it made with Excel.

# Installation

## Step 1

Install python at this address: https://www.python.org/downloads/  
Make sure your install pip and ADD TO PATH of your machine.

## Step 2

Install packages needed using pip: 
- Open your cmd and enter: 
> pip install openpyxl

## Step 3

Download this github project on your computer

# Using

## Step 1

Enter your stocks in the excel document (One table for each references)

## Step 2

Enter your orders in the Excel document

## Step 3

Close the excel document

## Step 4

Run the python programm

## Step 5

Print out the results of the excel document
