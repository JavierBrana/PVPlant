var map = L.map('map').setView([28.7041, 77.1025], 13);
//L.esri.basemapLayer("Topographic").addTo(map);
L.tileLayer('http://{s}.tile.osm.org/{z}/{x}/{y}.png', {
  attribution: '&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);

//Edit Toolbar

var drawnItems = new L.FeatureGroup();
map.addLayer(drawnItems);

var drawControl = new L.Control.Draw({
  draw: {
    position: 'topleft',
    polygon: {
      allowIntersection: false,
      drawError: {
        color: '#b00b00',
        timeout: 1000
      },
      showArea: true
    },
    circle: {
      shapeOptions: {
        color: '#662d91'
      }
    },
    polyline: false,
    rectangle: true,
    marker: false,
  },
  edit: {
    featureGroup: drawnItems
  }
});
map.addControl(drawControl);

map.on('draw:created', function(e) {
  var type = e.layerType,
    layer = e.layer;
  drawnItems.addLayer(layer);
});